//
//  SchedulerTests.swift
//  SchedulerTests
//
//  Created by Micheal Willard on 11/4/16.
//  Copyright © 2016 Micheal Willard. All rights reserved.
//

import XCTest
import UIKit

class SchedulerTests: XCTestCase {
    // MARK: Scheduler Tests
    
    // Tests to confirm that the Game initializer returns when no opp_name or location is entered
    func testGameInitialization() {
        /*
        // Success Case.
        let potentialGame = Game(opp_name: "Rays", location: "Chief Sealth High School", date: "9/2/2016", time: "7:00PM")
        XCTAssertNotNil(potentialGame)
        
        // Falure Cases.
        let noOppName = Game(opp_name: "", location: "Chief Sealth High School", date: "9/2/2016", time: "7:00PM")
        XCTAssertNotNil(noOppName)
        
        let noLocation = Game(opp_name: "Rays", location: "", date: "9/2/2016", time: "7:00PM")
        XCTAssertNotNil(noLocation)
        */
    }
}
